package com.example.lostandfound;

public class User {

    public String fullName,stuID,email;

    public User(){


    }

    public User(String fullName,String stuID,String email){
        this.fullName=fullName;
        this.stuID=stuID;
        this.email=email;
    }
}
